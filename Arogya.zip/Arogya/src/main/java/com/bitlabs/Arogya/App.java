package com.bitlabs.Arogya;


public class App {

    public static void main(String [] args) {
    PatientInterface dao=new PatientImpl();
    Patient p=new Patient();
    
    p.setId(110);
    p.setAge(23);
    p.setName("mohan");
    p.setGender("male");
    p.setCity("bhimavaram");
    p.setAddress("4-5,vijayawada");
    p.setGuardian_name("pavan");
    p.setGuardian_address("4-5");
    p.setDateOfAdmission("1992/08/22");
    p.setAadhar_Card_number(123432);
    p.setContact_number(96189265);
    p.setGuardian_contactNumber(770236);
    
   //dao.patientRegistration(p);
    
    
   //dao.viewAllPatient();
    
    //dao.searchPatientById(107);
    
   //dao.deletePatientById(102);
    
   // dao.searchPatientByCity("eluru");
    
    dao.searchPatientByAgeGroup(18, 55);
    
}

}